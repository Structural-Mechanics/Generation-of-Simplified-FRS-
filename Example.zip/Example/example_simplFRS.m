
% # =============================================================================
% # =============================================================================
% #
% # simpl_FRS: Generation of simplified Floor Response Spectra
% #
% # =============================================================================
% # =============================================================================
% 
% # Simone kaldas
% # simone.kaldas@ext.f4e.europa.eu
% # v1.0
% 
% '''
% Description
% This script is used to generate simplified curves of Floor Response Spectra 
% using as an example input files from a previous modal analysis of a
% 2-DOFs system excited with the following spectrum.
% 
% Input data
% -Natural frequencies: are stored in the first column of the file
% 'part.txt' and in the first column of the file 'modal_displacement.txt'
%
% -Participation factors: are stored in the last column of the file 'partic.txt'
% and represent participation factors of the system in the considered
% direction e.g. x or y or z
%     
% -Input response spectrum: is stored in 'ground.txt', where the second
% column contains spectral values  at the corresponding frequency values in 
% the second column 
% 
% - Reference FRS: is stored in 'referece_FRS.txt', spectral values in the 
% second column associated to the frequency values in the first column of the
% file have been obtained through a direct dynamic analysis, in order to
% compare it with the simplified FRS generated.
%
% # =============================================================================

f = (0:0.01:50)';

modal_results = importdata('part.txt','\t');
eig_freq = modal_results(:,1);
pfact= modal_results(:,2); 

disp = importdata('modal_displacement.txt','\t');
mode_shapes = disp(:,2);

% ground spectra must be defined for the same frequency values of the
% output collected in f
ground_spectrum = importdata('ground.txt',' ');
ground_f = [ 0; ground_spectrum(:,1)];      %add a 0 at first position
ground_SA = [ 0; ground_spectrum(:,2)];
ground = interp1(ground_f,ground_SA,f,'linear','extrap');

dynamic_FRS = importdata('reference_FRS.txt','\t');
reference_FRS = dynamic_FRS(:,2);

xi_struct = 0.05;
xi = 0.05;
fc = 8;

FRS = simpl_FRS(f,ground,eig_freq,mode_shapes,pfact,xi_struct,xi,fc);

plot(f,ground,'b',f,FRS,'r',f,reference_FRS,'g')
xlabel('Frequency [Hz]')
ylabel('Sa [m/s^{2}]')
legend({'Ground','Simplified Spectrum','Dynamic Spectrum'})
saveas(gcf,'output_simpl_FRS.png')
